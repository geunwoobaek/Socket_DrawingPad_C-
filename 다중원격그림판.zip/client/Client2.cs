﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net;
using System.Net.Sockets;
using System.Threading;
namespace client
{
    public partial class Client2 : Form
    {
      
       public TcpClient client = new TcpClient();
       public NetworkStream stream = default(NetworkStream);
        string message = string.Empty;
        bool m_bConnect;
        public int signal = 0;
        public Client2()
        {
            InitializeComponent();       
        }
        private void Form2_Load(object sender, EventArgs e)
        {
        }
        private void button1_Click(object sender, EventArgs e)
        {
            Connect();
        }
        public bool Connect()
        {
            client = new TcpClient();
            var port = int.Parse(PORT_TEXT.Text);
            IPAddress localAddr = IPAddress.Parse(IP_TEXT.Text);

            try
            {
                client.Connect(localAddr, port);
                btn_Connect.Text = "연결 끉기";
                MessageBox.Show("서버에 연결!!.");
                stream = client.GetStream();
                signal = 1;
            }
            catch (SocketException E)
            {
                m_bConnect = false;
                MessageBox.Show("해당서버가 없습니다.");
                return true;
            }
            m_bConnect = true;
            return false;
        }
         


     
       

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void UserName_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
