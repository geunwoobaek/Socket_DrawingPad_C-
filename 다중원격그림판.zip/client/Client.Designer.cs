﻿namespace client
{
    partial class Client
    {
        /// <summary>
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 디자이너에서 생성한 코드

        /// <summary>
        /// 디자이너 지원에 필요한 메서드입니다. 
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마세요.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Client));
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.SelectButton = new System.Windows.Forms.ToolStripDropDownButton();
            this.handItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pencilItem = new System.Windows.Forms.ToolStripMenuItem();
            this.LineItem = new System.Windows.Forms.ToolStripMenuItem();
            this.CircleItem = new System.Windows.Forms.ToolStripMenuItem();
            this.RectItem = new System.Windows.Forms.ToolStripMenuItem();
            this.Line_Button = new System.Windows.Forms.ToolStripDropDownButton();
            this.line1_item = new System.Windows.Forms.ToolStripMenuItem();
            this.line2_item = new System.Windows.Forms.ToolStripMenuItem();
            this.line3_item = new System.Windows.Forms.ToolStripMenuItem();
            this.line4_item = new System.Windows.Forms.ToolStripMenuItem();
            this.line5_item = new System.Windows.Forms.ToolStripMenuItem();
            this.fill_Button = new System.Windows.Forms.ToolStripButton();
            this.ColorButton1 = new System.Windows.Forms.ToolStripButton();
            this.ColorButton2 = new System.Windows.Forms.ToolStripButton();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.sendBox = new System.Windows.Forms.TextBox();
            this.Say = new System.Windows.Forms.Button();
            this.panel1 = new client.DoubleBufferPanel();
            this.toolStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // toolStrip1
            // 
            this.toolStrip1.ImageScalingSize = new System.Drawing.Size(24, 24);
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.SelectButton,
            this.Line_Button,
            this.fill_Button,
            this.ColorButton1,
            this.ColorButton2});
            this.toolStrip1.Location = new System.Drawing.Point(0, 0);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(702, 37);
            this.toolStrip1.TabIndex = 0;
            this.toolStrip1.Text = "toolStrip1";
            this.toolStrip1.ItemClicked += new System.Windows.Forms.ToolStripItemClickedEventHandler(this.toolStrip1_ItemClicked);
            // 
            // SelectButton
            // 
            this.SelectButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.SelectButton.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.handItem,
            this.pencilItem,
            this.LineItem,
            this.CircleItem,
            this.RectItem});
            this.SelectButton.Image = ((System.Drawing.Image)(resources.GetObject("SelectButton.Image")));
            this.SelectButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.SelectButton.Name = "SelectButton";
            this.SelectButton.Size = new System.Drawing.Size(38, 34);
            this.SelectButton.Text = "toolStripDropDownButton1";
            // 
            // handItem
            // 
            this.handItem.AutoSize = false;
            this.handItem.Image = ((System.Drawing.Image)(resources.GetObject("handItem.Image")));
            this.handItem.Name = "handItem";
            this.handItem.Size = new System.Drawing.Size(220, 30);
            this.handItem.Text = "Hand";
            this.handItem.Click += new System.EventHandler(this.handItem_Click);
            // 
            // pencilItem
            // 
            this.pencilItem.Image = ((System.Drawing.Image)(resources.GetObject("pencilItem.Image")));
            this.pencilItem.ImageTransparentColor = System.Drawing.Color.Black;
            this.pencilItem.Name = "pencilItem";
            this.pencilItem.Size = new System.Drawing.Size(125, 26);
            this.pencilItem.Text = "Pencil";
            this.pencilItem.Click += new System.EventHandler(this.pencilItem_Click);
            // 
            // LineItem
            // 
            this.LineItem.Image = ((System.Drawing.Image)(resources.GetObject("LineItem.Image")));
            this.LineItem.Name = "LineItem";
            this.LineItem.Size = new System.Drawing.Size(125, 26);
            this.LineItem.Text = "Line";
            this.LineItem.Click += new System.EventHandler(this.LineItem_Click);
            // 
            // CircleItem
            // 
            this.CircleItem.Image = ((System.Drawing.Image)(resources.GetObject("CircleItem.Image")));
            this.CircleItem.Name = "CircleItem";
            this.CircleItem.Size = new System.Drawing.Size(125, 26);
            this.CircleItem.Text = "Circle";
            this.CircleItem.Click += new System.EventHandler(this.CircleItem_Click);
            // 
            // RectItem
            // 
            this.RectItem.Image = ((System.Drawing.Image)(resources.GetObject("RectItem.Image")));
            this.RectItem.Name = "RectItem";
            this.RectItem.Size = new System.Drawing.Size(125, 26);
            this.RectItem.Text = "Rect";
            this.RectItem.Click += new System.EventHandler(this.RectItem_Click);
            // 
            // Line_Button
            // 
            this.Line_Button.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.Line_Button.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.line1_item,
            this.line2_item,
            this.line3_item,
            this.line4_item,
            this.line5_item});
            this.Line_Button.Image = ((System.Drawing.Image)(resources.GetObject("Line_Button.Image")));
            this.Line_Button.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.Line_Button.Name = "Line_Button";
            this.Line_Button.Size = new System.Drawing.Size(38, 34);
            this.Line_Button.Text = "toolStripDropDownButton2";
            // 
            // line1_item
            // 
            this.line1_item.Image = ((System.Drawing.Image)(resources.GetObject("line1_item.Image")));
            this.line1_item.Name = "line1_item";
            this.line1_item.Size = new System.Drawing.Size(92, 26);
            this.line1_item.Text = "1";
            this.line1_item.Click += new System.EventHandler(this.line1_item_Click);
            // 
            // line2_item
            // 
            this.line2_item.Image = ((System.Drawing.Image)(resources.GetObject("line2_item.Image")));
            this.line2_item.Name = "line2_item";
            this.line2_item.Size = new System.Drawing.Size(92, 26);
            this.line2_item.Text = "2";
            this.line2_item.Click += new System.EventHandler(this.line2_item_Click);
            // 
            // line3_item
            // 
            this.line3_item.Image = ((System.Drawing.Image)(resources.GetObject("line3_item.Image")));
            this.line3_item.Name = "line3_item";
            this.line3_item.Size = new System.Drawing.Size(92, 26);
            this.line3_item.Text = "3";
            this.line3_item.Click += new System.EventHandler(this.line3_item_Click);
            // 
            // line4_item
            // 
            this.line4_item.Image = ((System.Drawing.Image)(resources.GetObject("line4_item.Image")));
            this.line4_item.Name = "line4_item";
            this.line4_item.Size = new System.Drawing.Size(92, 26);
            this.line4_item.Text = "4";
            this.line4_item.Click += new System.EventHandler(this.line4_item_Click);
            // 
            // line5_item
            // 
            this.line5_item.Image = ((System.Drawing.Image)(resources.GetObject("line5_item.Image")));
            this.line5_item.Name = "line5_item";
            this.line5_item.Size = new System.Drawing.Size(92, 26);
            this.line5_item.Text = "5";
            this.line5_item.Click += new System.EventHandler(this.line5_item_Click);
            // 
            // fill_Button
            // 
            this.fill_Button.AutoSize = false;
            this.fill_Button.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.fill_Button.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.fill_Button.Name = "fill_Button";
            this.fill_Button.Size = new System.Drawing.Size(50, 34);
            this.fill_Button.Text = "채우기";
            this.fill_Button.Click += new System.EventHandler(this.toolStripButton1_Click_1);
            // 
            // ColorButton1
            // 
            this.ColorButton1.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.ColorButton1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.ColorButton1.Image = ((System.Drawing.Image)(resources.GetObject("ColorButton1.Image")));
            this.ColorButton1.ImageTransparentColor = System.Drawing.Color.DarkSlateGray;
            this.ColorButton1.Name = "ColorButton1";
            this.ColorButton1.Size = new System.Drawing.Size(28, 34);
            this.ColorButton1.Text = "toolStripButton2";
            this.ColorButton1.Click += new System.EventHandler(this.ColorButton1_Click);
            // 
            // ColorButton2
            // 
            this.ColorButton2.AutoSize = false;
            this.ColorButton2.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.ColorButton2.Image = ((System.Drawing.Image)(resources.GetObject("ColorButton2.Image")));
            this.ColorButton2.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.ColorButton2.Name = "ColorButton2";
            this.ColorButton2.Size = new System.Drawing.Size(30, 34);
            this.ColorButton2.Text = "toolStripButton3";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(0, 376);
            this.textBox1.Multiline = true;
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(700, 155);
            this.textBox1.TabIndex = 0;
            this.textBox1.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // sendBox
            // 
            this.sendBox.Location = new System.Drawing.Point(0, 529);
            this.sendBox.Name = "sendBox";
            this.sendBox.Size = new System.Drawing.Size(639, 25);
            this.sendBox.TabIndex = 2;
            this.sendBox.TextChanged += new System.EventHandler(this.textBox2_TextChanged);
            // 
            // Say
            // 
            this.Say.Location = new System.Drawing.Point(637, 527);
            this.Say.Name = "Say";
            this.Say.Size = new System.Drawing.Size(63, 25);
            this.Say.TabIndex = 3;
            this.Say.Text = "Say";
            this.Say.UseVisualStyleBackColor = true;
            this.Say.Click += new System.EventHandler(this.Say_Click);
            // 
            // panel1
            // 
            this.panel1.Location = new System.Drawing.Point(0, 40);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(700, 330);
            this.panel1.TabIndex = 1;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            this.panel1.MouseDown += new System.Windows.Forms.MouseEventHandler(this.panel1_MouseDown);
            this.panel1.MouseMove += new System.Windows.Forms.MouseEventHandler(this.panel1_MouseMove);
            this.panel1.MouseUp += new System.Windows.Forms.MouseEventHandler(this.panel1_MouseUp);
            // 
            // Client
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(702, 553);
            this.Controls.Add(this.Say);
            this.Controls.Add(this.sendBox);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.toolStrip1);
            this.Name = "Client";
            this.Text = "세계그림판";
            this.Load += new System.EventHandler(this.Client_Load);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Client_KeyDown);
            this.KeyUp += new System.Windows.Forms.KeyEventHandler(this.Client_KeyUp);
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ToolStrip toolStrip1;

        private System.Windows.Forms.Button Say;
        public System.Windows.Forms.TextBox textBox1;
        public System.Windows.Forms.TextBox sendBox;
        private System.Windows.Forms.ToolStripDropDownButton SelectButton;
        private System.Windows.Forms.ToolStripDropDownButton Line_Button;
        private System.Windows.Forms.ToolStripButton fill_Button;
        private System.Windows.Forms.ToolStripButton ColorButton1;
        private System.Windows.Forms.ToolStripButton ColorButton2;
        private System.Windows.Forms.ToolStripMenuItem handItem;
        private System.Windows.Forms.ToolStripMenuItem pencilItem;
        private System.Windows.Forms.ToolStripMenuItem LineItem;
        private System.Windows.Forms.ToolStripMenuItem CircleItem;
        private System.Windows.Forms.ToolStripMenuItem RectItem;
        private System.Windows.Forms.ToolStripMenuItem line1_item;
        private System.Windows.Forms.ToolStripMenuItem line2_item;
        private System.Windows.Forms.ToolStripMenuItem line3_item;
        private System.Windows.Forms.ToolStripMenuItem line4_item;
        private System.Windows.Forms.ToolStripMenuItem line5_item;
        private DoubleBufferPanel panel1;
    }
}

