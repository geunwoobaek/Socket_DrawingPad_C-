﻿using System;
using System.Net;
using System.Net.Sockets;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Threading;
using Packet_libirary;
using System.Drawing.Imaging;
namespace client
{
  
    public partial class Client : Form
    {
        
        bool draw = false;
        bool Mode_Draw = true;
        bool Mode_Rectangle = false;
        bool Mode_Line = false;
        bool Mode_Circle = false;
        bool Mode_Hand = false;
        bool Mode_Move = false;
     
        bool Shift = false;
        bool Key_F5 = false;
        Graphics Line_panel;
        private Object locker = new Object();
        int temp_x = 0;
        int temp_y = 0;
        int retC_x = 0;
        int retC_y = 0;
        int retC_Width = 0;
        int retC_height = 0;
        double ratio = 10;
        /////////////////////////////////////////////////////////////////////////////////////////     
        int pX = -1;
        int pY = -1;
        int MX = 0;
        int MY = 0;
        int Panel_x;
        int Panel_y;
        int centerx;
        int centery;
        Pen pen;
        Pen Line_pen;
        Bitmap drawing;
        Bitmap cloneBitmap;
        ColorDialog Cd;
        public int thick = 1;
        /////////////////////////////////////////////////////////////////////////////그리기변수들
        private BackgroundWorker worker;
        Client2 modal;
        public TcpClient client = new TcpClient();
        public NetworkStream stream = default(NetworkStream);
        string message = string.Empty;
        bool m_bConnect;
        public int signal = 0; 
        private object bufferLock = new object(); 
        /////////////////////////////////////////////////////////////////////////////////network;
        public Packet_libirary.PMessage message_Class;     
        public int nread;
        private byte[] sendBuffer = new byte[1024 * 54];
        private byte[] readBuffer = new byte[1024 * 54];
        /// packet;
        int[] S_pX;
        int[] S_py;
        int[] S_eX;
        int[] S_eY;
        int[] S_thick;
        string[] S_color;
        int index = 0;
        int PostionX = 0;
        int PostionY = 0;
        // int[] S_thick;
        // int Color;
        /// <summary>
        /// ///////////////////
        /// </summary>
        public Client()
        {
            //   pos = new List<Position>();
            S_pX = new int[1000];
            S_py= new int[1000];
            S_eX= new int[1000];
            S_eY= new int[1000];
            S_color = new string[1000];
            S_thick = new int[1000];
            centerx = 0;
            centery = 0;
            modal = new Client2();
            modal.Show();
            InitializeComponent();
            worker = new BackgroundWorker();
            worker.WorkerReportsProgress = true;
            worker.WorkerSupportsCancellation = true;
            worker.DoWork += new DoWorkEventHandler(worker_DoWork);
            worker.ProgressChanged += new ProgressChangedEventHandler(worker_ProgressChanged);
            worker.RunWorkerCompleted += new RunWorkerCompletedEventHandler(worker_RunWorkerCompleted);
            worker.RunWorkerAsync();
            drawing = new Bitmap(panel1.Width, panel1.Height, panel1.CreateGraphics());
            Graphics.FromImage(drawing).Clear(Color.White);
            panel1.CreateGraphics().DrawImageUnscaled(drawing, new Point(0, 0));
            cloneBitmap = ResizeImage(drawing, panel1.Width, panel1.Height, 0, 0);
            Panel_x = panel1.Width;
            Panel_y = panel1.Height;
           /// Graphics.FromImage(drawing).Clear(Color.White);
            Cd = new ColorDialog();
            Line_pen = new Pen(Color.Black);
            this.panel1.MouseWheel += new System.Windows.Forms.MouseEventHandler(this.panel1_MouseWheel);
        }
        void worker_DoWork(object sender, DoWorkEventArgs e)
        {
            while(true)
            {
                if(modal.signal == 1)
                {
                    stream = modal.stream;
                    message = "Connected to Chat Server";
                    PMessage Me = new PMessage();
                    Me.command = "처음접속";
                    Me.UserName = modal.UserName.Text;
                    Me.message = modal.UserName.Text + "Connect!!";
                    Packet.Serialize(Me).CopyTo(sendBuffer, 0);            
                    DisplayText(message);                                    
                    stream.Write(sendBuffer, 0, sendBuffer.Length);
                    stream.Flush();
                    Thread t_handler = new Thread(new ThreadStart(GetMessage));
                  //  try
                  //  {
                    //    drawing = new Bitmap("drawing2");
                      //  panel1.CreateGraphics().DrawImageUnscaled(drawing, new Point(0, 0));
                  //  }
                   // catch {; }
                    t_handler.IsBackground = true;
                    t_handler.Start();
                    break;
                 }       
            }
        }
        void worker_ProgressChanged(object sender, ProgressChangedEventArgs e)
        {
            MessageBox.Show("Change");
        }

        // 작업 완료 - UI Thread
        void worker_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            MessageBox.Show("success");
        }
      
      

        private void panel1_Paint(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }
        public bool Send()
        {
            return true;
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        public void Say_Click(object sender, EventArgs e)
        {        
            if (modal.signal == 1)
            {   
                sendBox.Focus();
                PMessage Me = new PMessage();
                Me.UserName = modal.UserName.Text;
                Me.command ="메시지";
                Me.message = sendBox.Text;     
                Packet.Serialize(Me).CopyTo(sendBuffer, 0);
                stream.Write(sendBuffer, 0, sendBuffer.Length);
                stream.Flush();
                DisplayText(modal.UserName.Text + " :" + sendBox.Text);
                sendBox.Text = "";
            }        
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {
            retC_x = Math.Min(pX, temp_x);
            retC_y = Math.Min(pY, temp_y);
            retC_Width = Math.Abs(pX - temp_x);
            retC_height = Math.Abs(pY - temp_y);
            if (Mode_Circle == true)
                e.Graphics.DrawEllipse(Line_pen, retC_x, retC_y, retC_Width, retC_height);
            if (Mode_Rectangle == true)
                e.Graphics.DrawRectangle(Line_pen, retC_x, retC_y, retC_Width, retC_height);
            if (Mode_Line == true)
                e.Graphics.DrawLine(Line_pen, pX, pY, temp_x, temp_y);
            e.Graphics.DrawImageUnscaled(drawing, new Point(centerx + MX, centery + MY));
            if (Mode_Circle == true)
                e.Graphics.DrawEllipse(Line_pen, retC_x, retC_y, retC_Width, retC_height);
            if (Mode_Rectangle == true)
                e.Graphics.DrawRectangle(Line_pen, retC_x, retC_y, retC_Width, retC_height);
            if (Mode_Line == true)
                e.Graphics.DrawLine(Line_pen, pX, pY, temp_x, temp_y);


        }

        private void panel1_MouseMove(object sender, MouseEventArgs e)
        {
            if (Mode_Move == true && Shift == true && Key_F5 == true)
            {
                // drawing = ResizeImage(cloneBitmap, panel1.Width, panel1.Height, 0, 0);        
                //  Graphics.FromImage(drawing).Clear(Color.White);
                //  panel1.CreateGraphics().DrawImageUnscaled(drawing, new Point(0, 0));
                // drawing = ResizeImage(cloneBitmap, panel1.Width, panel1.Height, 0, 0);
                panel1.CreateGraphics().DrawImageUnscaled(drawing, new Point(centerx + (e.X - pX), centery + (e.Y - pY)));
                MX = e.X - pX;
                MY = e.Y - pY;
            }
            else if (Mode_Draw == true)
            {
                lock (locker)
                {
                    if (draw)
                    {
                        Graphics panel = Graphics.FromImage(drawing);

                        Pen pen = new Pen(Cd.Color, thick);

                        pen.EndCap = LineCap.Round;
                        pen.StartCap = LineCap.Round;

                        panel.DrawLine(pen, pX - centerx - MX, pY - centery - MY, e.X - centerx - MX, e.Y - centery - MY);
                        panel1.CreateGraphics().DrawImageUnscaled(drawing, new Point(centerx + MX, centery + MY));
                        cloneBitmap = ResizeImage(drawing, panel1.Width, panel1.Height, 0, 0);
                     
                        string TransColor = ColorTranslator.ToHtml(Color.FromArgb(Cd.Color.ToArgb()));
                        S_pX[index] = (int)((pX - centerx - MX)/ (ratio/10));
                        S_py[index] = (int)((pY - centery - MY) / (ratio/10));
                        S_eX[index] = (int)((e.X - centerx - MX)/ (ratio/10));
                        S_eY[index] = (int)((e.Y - centery - MY) / (ratio/10));
                        S_color[index] = ColorTranslator.ToHtml(Color.FromArgb(Cd.Color.ToArgb()));
                        S_thick[index] = thick;
                        index++;


                    }
                }

                pX = e.X;
                pY = e.Y;

            }
            else if (Mode_Line == true || Mode_Circle == true || Mode_Rectangle)
            {
                if (draw)
                {
                    Graphics panel = Graphics.FromImage(drawing);

                    Line_pen = new Pen(Cd.Color, thick);

                    Line_pen.EndCap = LineCap.Round;
                    Line_pen.StartCap = LineCap.Round;
                    temp_x = e.X;
                    temp_y = e.Y;
                    panel1.Invalidate(true);
                    panel1.Update();
                    //////////////////////////////////////////////////////////
             

                }
            }

        }
        private void panel1_MouseDown(object sender, MouseEventArgs e)
        {
            if (Mode_Hand == true)
            {
                Mode_Move = true;
            }
            draw = true;

            pX = e.X;
            pY = e.Y;

        }

        private void panel1_MouseUp(object sender, MouseEventArgs e)
        {
            
                draw = false;
            stream = modal.stream;            
            if (Mode_Move == true )
            {
                Mode_Move = false;
            }
            else if (Mode_Line == true&&modal.signal==1)
            {
            
             //   MessageBox.Show("Dra@w");
                Line_pen = new Pen(Cd.Color, thick);

                Line_pen.EndCap = LineCap.Round;
                Line_pen.StartCap = LineCap.Round;

                Line_panel.DrawLine(Line_pen, pX - centerx - MX, pY - centery - MY, e.X - centerx - MX, e.Y-centery-MY);
                ////////////////////////////////////////////////////////////////////////
                S_pX[index] = (int)((pX - centerx - MX) / (ratio / 10));
                S_py[index] = (int)((pY - centery - MY) / (ratio / 10));
                S_eX[index] = (int)((e.X - centerx - MX) / (ratio / 10));
                S_eY[index] = (int)((e.Y - centery - MY) / (ratio / 10));
                S_color[index]=ColorTranslator.ToHtml(Color.FromArgb(Cd.Color.ToArgb()));
                S_thick[index] = thick;
                index++;
              ///////////////////////////////////////////////////////////////
                PMessage Me = new PMessage();
                Me.Color = S_color;
                Me.UserName = modal.UserName.Text;
                Me.command = "Draw_Line";
                Me.message = sendBox.Text;
                Me.thick = S_thick;
                Me.pX = S_pX;
                Me.py = S_py;
                Me.eX = S_eX;
                Me.eY = S_eY;
                Me.Data = index;
                Packet.Serialize(Me).CopyTo(sendBuffer, 0);
                stream.Write(sendBuffer, 0, sendBuffer.Length);
                stream.Flush();

            }
            else if (Mode_Circle == true)
            {
                retC_x = Math.Min(pX, temp_x);
                retC_y = Math.Min(pY, temp_y);
                retC_Width = Math.Abs(pX - temp_x);
                retC_height = Math.Abs(pY - temp_y);

                Line_pen = new Pen(Cd.Color, thick);

                Line_pen.EndCap = LineCap.Round;
                Line_pen.StartCap = LineCap.Round;

                Line_panel.DrawEllipse(Line_pen, retC_x - centerx - MX, retC_y - centery - MY, retC_Width, retC_height);
                /////////////////////////////////////////////////
                S_pX[index] = (int)((retC_x - centerx - MX) / (ratio / 10));
                S_py[index] = (int)((retC_y - centery - MY) / (ratio / 10));
                S_eX[index] = (int)((retC_Width) / (ratio / 10));
                S_eY[index] = (int)((retC_height)/(ratio/10));
                S_color[index] = ColorTranslator.ToHtml(Color.FromArgb(Cd.Color.ToArgb()));
                S_thick[index] = thick;
                index++;
                ///////////////////////
                PMessage Me = new PMessage();
                Me.Color = S_color;
                Me.UserName = modal.UserName.Text;
                Me.command = "Draw_Circle";
                Me.message = sendBox.Text;
                Me.thick = S_thick;
                Me.pX = S_pX;
                Me.py = S_py;
                Me.eX = S_eX;
                Me.eY = S_eY;
                Me.Data = index;
                Packet.Serialize(Me).CopyTo(sendBuffer, 0);
                stream.Write(sendBuffer, 0, sendBuffer.Length);
                stream.Flush();
            }

            else if (Mode_Rectangle == true)
            {
                retC_x = Math.Min(pX, temp_x);
                retC_y = Math.Min(pY, temp_y);
                retC_Width = Math.Abs(temp_x - pX);
                retC_height = Math.Abs(temp_y - pY);

                Line_pen = new Pen(Cd.Color, thick);

                Line_pen.EndCap = LineCap.Round;
                Line_pen.StartCap = LineCap.Round;

                Line_panel.DrawRectangle(Line_pen, retC_x - centerx - MX, retC_y - centery - MY, retC_Width, retC_height);
                ////////////////////////////////////////
                /////////////////////////////////////////////////
                S_pX[index] = (int)((retC_x - centerx - MX) / (ratio / 10));
                S_py[index] = (int)((retC_y - centery - MY) / (ratio / 10));
                S_eX[index] = (int)((retC_Width) / (ratio / 10));
                S_eY[index] = (int)((retC_height) / (ratio / 10));
                S_color[index] = ColorTranslator.ToHtml(Color.FromArgb(Cd.Color.ToArgb()));
                S_thick[index] = thick;
                index++;
                ///////////////////////
                PMessage Me = new PMessage();
                Me.Color = S_color;
                Me.UserName = modal.UserName.Text;
                Me.command = "Draw_Rectangle";
                Me.message = sendBox.Text;
                Me.thick = S_thick;
                Me.pX = S_pX;
                Me.py = S_py;
                Me.eX = S_eX;
                Me.eY = S_eY;
                Me.Data = index;
                Packet.Serialize(Me).CopyTo(sendBuffer, 0);
                stream.Write(sendBuffer, 0, sendBuffer.Length);
                stream.Flush();

            }
            else if(modal.signal==1)
            {
                PMessage Me = new PMessage();
                Me.UserName = modal.UserName.Text;
                Me.command = "Draw_Pencil";
                Me.message = sendBox.Text;
                Me.thick = S_thick;
                Me.Color = S_color;
                Me.pX = S_pX;
                Me.py = S_py;
                Me.eX = S_eX;
                Me.eY = S_eY;
                Me.Data = index;
                Packet.Serialize(Me).CopyTo(sendBuffer, 0);
                stream.Write(sendBuffer, 0, sendBuffer.Length);
                stream.Flush();
            }
            cloneBitmap = ResizeImage(drawing, panel1.Width, panel1.Height, 0, 0);
        }
        private void panel1_MouseWheel(object sender, System.Windows.Forms.MouseEventArgs e)
        {
            
            if (Mode_Hand == true)
            {
             //   sendBox.Text = "Shift";
                if (e.Delta != 0 && Panel_y > (panel1.Height / 5))
                {
                    //  Graphics.FromImage(drawing).Clear(Color.White);
                    //drawing = ResizeImage(cloneBitmap, panel1.Width*2, panel1.Height*2, e.X, e.Y);
                   // Graphics.FromImage(drawing).Clear(Color.White);
                 //   panel1.CreateGraphics().DrawImageUnscaled(drawing, new Point(PostionX / 2, PostionY / 2));
                }              
                if (e.Delta > 0 && panel1.Width * 5 > Panel_x)
                {
                    ratio += 2;
                    Panel_x += panel1.Width / 5;
                    PostionX -= panel1.Width / 5;
                    Panel_y += panel1.Height / 5;
                    PostionY -= panel1.Height / 5;
                    centerx = -(Panel_x - panel1.Width) / 2;
                    centery = -(Panel_y - panel1.Height) / 2;
                    drawing = ResizeImage(cloneBitmap, Panel_x, Panel_y, panel1.Width / 10, panel1.Width / 10);
                    panel1.CreateGraphics().DrawImageUnscaled(drawing, new Point(centerx, centery));
                    textBox1.Text = centerx.ToString() + " ," + (drawing.Width / 2).ToString();


                }
                else if (e.Delta < 0 && Panel_y > (panel1.Height / 5))
                {
                    ratio -= 2;
                    Panel_x -= panel1.Width / 5;
                    PostionX += panel1.Width / 5;
                    Panel_y -= panel1.Height / 5;
                    PostionY += panel1.Height / 5;
                    centerx = -(Panel_x - panel1.Width) / 2;
                    centery = -(Panel_y - panel1.Height) / 2;
                    drawing = ResizeImage(cloneBitmap, Panel_x, Panel_y, -panel1.Width / 10, -panel1.Width / 10);
                    panel1.CreateGraphics().DrawImageUnscaled(drawing, new Point(centerx, centery));
                    textBox1.Text = centerx.ToString() + " ," + (drawing.Width / 2).ToString();
                }
            }
        }
        public static Bitmap ResizeImage(Bitmap image, int width, int height, int x, int y)
        {
            var destRect = new Rectangle(0, 0, width, height);
            var destImage = new Bitmap(width, height);

            destImage.SetResolution(image.HorizontalResolution, image.VerticalResolution);

            using (var graphics = Graphics.FromImage(destImage))
            {
                graphics.CompositingMode = CompositingMode.SourceCopy;
                graphics.CompositingQuality = CompositingQuality.HighQuality;
                graphics.InterpolationMode = InterpolationMode.HighQualityBicubic;
                graphics.SmoothingMode = SmoothingMode.HighQuality;
                graphics.PixelOffsetMode = PixelOffsetMode.HighQuality;

                using (var wrapMode = new ImageAttributes())
                {
                    wrapMode.SetWrapMode(WrapMode.TileFlipXY);
                    graphics.DrawImage(image, destRect, 0, 0, image.Width, image.Height, GraphicsUnit.Pixel, wrapMode);
                }
            }

            return destImage;
        }
        private void DisplayText(string text)
        {
            if (textBox1.InvokeRequired)
            {
                textBox1.BeginInvoke(new MethodInvoker(delegate
                {
                    textBox1.AppendText(text + Environment.NewLine);
                }));
            }
            else
                textBox1.AppendText(text + Environment.NewLine);
        }
        private void GetMessage()
        {
            while (true)
            {
                if (stream.CanRead)
                {
                    stream.Read(readBuffer, 0, 1024 * 54);
                    PMessage Pm = new PMessage();
                    Pm = (PMessage)Packet.Desserialize(this.readBuffer);
                    if (Pm.command == "메시지")
                        DisplayText(Pm.UserName + ": " + Pm.message);
                   else if (Pm.command == "AllDraw")
                    {
                        lock (bufferLock)
                        {
                            Graphics panel = Graphics.FromImage(drawing);
                            for (int i = 0; i < Pm.Data; i++)
                            {
                                Pen pen = new Pen(System.Drawing.ColorTranslator.FromHtml(Pm.Color[i]), Pm.thick[i]);
                                pen.EndCap = LineCap.Round;
                                pen.StartCap = LineCap.Round;
                                if (Pm.Rec.Contains(i))
                                    panel.DrawRectangle(pen, Pm.pX[i], Pm.py[i], Pm.eX[i], Pm.eY[i]);
                                else if (Pm.Cir.Contains(i))
                                    panel.DrawEllipse(pen, Pm.pX[i], Pm.py[i], Pm.eX[i], Pm.eY[i]);
                                else
                                panel.DrawLine(pen, Pm.pX[i], Pm.py[i], Pm.eX[i], Pm.eY[i]);
                            }

                            panel1.CreateGraphics().DrawImageUnscaled(drawing, new Point(0, 0));
                        }
                    }
                    
                }
            }
        }

        private void toolStripButton1_Click(object sender, EventArgs e)
        {

        }

        private void toolStripButton1_Click_1(object sender, EventArgs e)
        {

        }

        private void toolStripMenuItem3_Click(object sender, EventArgs e)
        {
            thick = 2;
        }

        private void toolStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {
          
        }

        private void handItem_Click(object sender, EventArgs e)
        {
            Mode_Hand = true;
            Mode_Draw = false;
            Mode_Rectangle = false;
            //Line_panel = Graphics.FromImage(drawing);
            Mode_Line = false;
            Mode_Circle = false;
        }

        private void pencilItem_Click(object sender, EventArgs e)
        {
            Mode_Hand = false;
            Mode_Draw = true;
            Mode_Rectangle = false;
            Mode_Line = false;
            Mode_Circle = false;
        }

        private void LineItem_Click(object sender, EventArgs e)
        {
            Mode_Hand = false;
            Mode_Draw = false;
            Mode_Rectangle = false;
            Mode_Line = true;
            Line_panel = Graphics.FromImage(drawing);
            Mode_Circle = false;
        }

        private void CircleItem_Click(object sender, EventArgs e)
        {
            Mode_Hand = false;
            Mode_Draw = false;
            Mode_Rectangle = false;
            Mode_Line = false;
            Line_panel = Graphics.FromImage(drawing);
            Mode_Circle = true;
        }

        private void RectItem_Click(object sender, EventArgs e)
        {
            Mode_Hand = false;
            Mode_Draw = false;
            Mode_Rectangle = true;
            Line_panel = Graphics.FromImage(drawing);
            Mode_Line = false;
            Mode_Circle = false;
        }

     

        private void line1_item_Click(object sender, EventArgs e)
        {
            thick = 1;
        }

        private void line2_item_Click(object sender, EventArgs e)
        {
            thick = 2;
        }

        private void line3_item_Click(object sender, EventArgs e)
        {
            thick = 3;
        }

        private void line4_item_Click(object sender, EventArgs e)
        {
            thick = 4;
        }

        private void line5_item_Click(object sender, EventArgs e)
        {
            thick = 5;
        }

        private void ColorButton1_Click(object sender, EventArgs e)
        {
            if (Cd.ShowDialog() == DialogResult.OK)
                ;
            else
                pen.Color = Color.Black;
        }

        private void Client_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.ShiftKey)
            {
                Shift = true;
            }
            if (e.KeyCode == Keys.F5)
            {
                Key_F5 = true;
            }
        }

        private void Client_KeyUp(object sender, KeyEventArgs e)
        {
            Shift = false;
            Key_F5 = false;
        }

        private void Client_Load(object sender, EventArgs e)
        {
            this.KeyPreview = true;
        }
    }
}
