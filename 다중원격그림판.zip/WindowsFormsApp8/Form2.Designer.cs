﻿namespace WindowsFormsApp8
{
    partial class server2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.IP_TEXT = new System.Windows.Forms.TextBox();
            this.PORT_TEXT = new System.Windows.Forms.TextBox();
            this.server_button = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // IP_TEXT
            // 
            this.IP_TEXT.Location = new System.Drawing.Point(21, 28);
            this.IP_TEXT.Name = "IP_TEXT";
            this.IP_TEXT.Size = new System.Drawing.Size(228, 25);
            this.IP_TEXT.TabIndex = 0;
            this.IP_TEXT.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // PORT_TEXT
            // 
            this.PORT_TEXT.Location = new System.Drawing.Point(273, 28);
            this.PORT_TEXT.Name = "PORT_TEXT";
            this.PORT_TEXT.Size = new System.Drawing.Size(106, 25);
            this.PORT_TEXT.TabIndex = 1;
            // 
            // server_button
            // 
            this.server_button.Location = new System.Drawing.Point(21, 73);
            this.server_button.Name = "server_button";
            this.server_button.Size = new System.Drawing.Size(358, 31);
            this.server_button.TabIndex = 2;
            this.server_button.Text = "서버 열기";
            this.server_button.UseVisualStyleBackColor = true;
            this.server_button.Click += new System.EventHandler(this.button1_Click);
            // 
            // server2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(391, 116);
            this.Controls.Add(this.server_button);
            this.Controls.Add(this.PORT_TEXT);
            this.Controls.Add(this.IP_TEXT);
            this.Name = "server2";
            this.Text = "세계그림판서버";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.server2_FormClosed);
            this.Load += new System.EventHandler(this.server2_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox IP_TEXT;
        private System.Windows.Forms.TextBox PORT_TEXT;
        private System.Windows.Forms.Button server_button;
    }
}