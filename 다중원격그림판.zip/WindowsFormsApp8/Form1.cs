﻿using System;
using System.IO;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;
using System.Net;
using System.Net.Sockets;


namespace WindowsFormsApp8
{
    public partial class server1 : Form
    {
       public Bitmap drawing;
        public server1()
        {
            InitializeComponent();
          
        }
       

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void server1_Load(object sender, EventArgs e)
        {
            
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
        }

        private void server1_FormClosed(object sender, FormClosedEventArgs e)
        {
            Bitmap Newimg = new Bitmap(drawing);

           drawing.Dispose();

           drawing = null;
            if (File.Exists("drawing"))
            {
                GC.Collect();
                GC.WaitForPendingFinalizers();
                FileInfo f = new FileInfo("drawing");
                f.Delete();
            }
            else
            Newimg.Save("drawing", System.Drawing.Imaging.ImageFormat.Bmp);
   
        }
    }
}
