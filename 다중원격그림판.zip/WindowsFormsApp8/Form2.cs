﻿using System;
using System.Net;
using System.Net.Sockets;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;
using System.IO;//
using Packet_libirary;

namespace WindowsFormsApp8
{
    public partial class server2 : Form
    {
        private byte[] sendBuffer = new byte[1024 * 54];
        private byte[] readBuffer = new byte[1024 * 54];
        /// <summary>
        Pen pen;
        Pen Line_pen;
        //Bitmap drawing;
        /// </summary>
        int nread;
        int[] Circle ;
        int Cir_index = 0;
        int[] Rec;
        int Rec_index = 0;
        int[] Line;
        int Line_index = 0;
        int all_index = 0;
        int[] S_pX;
        int[] S_py;
        int[] S_eX;
        int[] S_eY;
        int[] S_thick;
        string[] S_color;
        /// //////////////////////////////////////////

        server1 dialog;
        public NetworkStream m_Stream;
        TcpClient clientSocket = null; // 소켓
        static int counter = 0; // 사용자 수
        string date; // 날짜 
        private TcpListener Server;
        PMessage BackUp = new PMessage();
        public bool Collected = false;
        // 각 클라이언트 마다 리스트에 추가
        public Dictionary<TcpClient, string> clientList = new Dictionary<TcpClient, string>();
        public server2()
        {
            InitializeComponent();
            S_pX = new int[1000];
            S_py = new int[1000];
            S_eX = new int[1000];
            S_eY = new int[1000];
            S_color = new string[1000];
            S_thick = new int[1000];        
            Line = new int[1000];
            Rec = Enumerable.Repeat<int>(-1, 1000).ToArray<int>();
            Circle = Enumerable.Repeat<int>(-1, 1000).ToArray<int>();
             dialog = new server1();
            try { dialog.drawing = new Bitmap("drawing");
                dialog.panel1.CreateGraphics().DrawImageUnscaled(dialog.drawing, new Point(0, 0));
            }
            catch
            {
                dialog.drawing = new Bitmap(dialog.drawing = new Bitmap(dialog.panel1.Width, dialog.panel1.Height, dialog.panel1.CreateGraphics()));
                Graphics.FromImage(dialog.drawing).Clear(Color.White);
            }         
            dialog.Show();
        }
        public void Send()
        {
            m_Stream.Write(sendBuffer, 0, sendBuffer.Length);
            m_Stream.Flush();

            Array.Clear(sendBuffer, 0, sendBuffer.Length);
        }
     
        
        public void Listen()
           {
            var port = int.Parse(PORT_TEXT.Text);
            IPAddress localAddr = IPAddress.Parse(IP_TEXT.Text);
            try
            {
                Server = new TcpListener(localAddr, port);
                //readBuffer = null;
                Server.Start();
                DisplayText(">> Server Started");
                Collected = true;
                while (true)
                {
                    try
                    {
                        counter++; // Client 수 증가
                        clientSocket = Server.AcceptTcpClient(); // client 소켓 접속 허용       
                        NetworkStream stream = clientSocket.GetStream();
                        if (counter > 1)
                        {
                            Packet.Serialize(BackUp).CopyTo(this.sendBuffer, 0);//이전에 한번보냈었던 패킷메시지
                            stream.Write(sendBuffer, 0, sendBuffer.Length);
                            stream.Flush();
                        }
                        PMessage Pm = new PMessage();
                        stream.Read(readBuffer, 0, 1024 * 54);
                        Pm = (PMessage)Packet.Desserialize(this.readBuffer);
                        DisplayText(Pm.UserName+" Connect");
                        clientList.Add(clientSocket, Pm.UserName); // cleint 리스트에 추가
                        Thread t_hanlder = new Thread(() => OnReceived());
                        t_hanlder.IsBackground = true;
                        t_hanlder.Start();
                       
                    }
                    catch (SocketException se) { break; }
                    catch (Exception ex) { break; }
                }

                clientSocket.Close(); // client 소켓 닫기
                Server.Stop(); // 서버 종료
            }
            catch (SocketException e)
            {
                IP_TEXT.Text = "IP or PORT error";
                Server.Stop();
            }
        }
        public void OnReceived()
        {
                NetworkStream stream = clientSocket.GetStream();
                PMessage Pm = new PMessage();
            
            while (true)
            {
                try { stream.Read(readBuffer, 0, 1024 * 54);
                }
                catch
                {
                    clientList.Remove(clientSocket);
                  return;
                }
            //    MessageBox.Show(Pm.command);
                Pm = (PMessage)Packet.Desserialize(this.readBuffer);
                
                if (Pm.command == "처음접속")
                {
                    string displaymessage = "User " + Pm.UserName + " : " + Pm.message;
                    DisplayText(displaymessage);// 사람이 들어온걸 메시지를뿌리기..
                    
               
                    Packet.Serialize(BackUp).CopyTo(this.sendBuffer, 0);
                    stream.Write(sendBuffer, 0, sendBuffer.Length);
                    stream.Flush();

                    Array.Clear(sendBuffer, 0, sendBuffer.Length);
                }
                else if (Pm.command == "메시지")
                {
                    string displaymessage = "User " + Pm.UserName + " : " + Pm.message;
                    DisplayText(displaymessage);// 사람이 들어온걸 메시지를뿌리기..
                }
                else
                {
                    if (Pm.command == "Draw_Pencil")
                    {
                        // MessageBox.Show("Draw");
                        // dialog.textBox2.Text = "Draw";
                        Graphics panel = Graphics.FromImage(dialog.drawing);

                        for (int i = all_index; i < Pm.Data; i++)
                        {
                            Pen pen = new Pen(System.Drawing.ColorTranslator.FromHtml(Pm.Color[i]), Pm.thick[i]);
                            pen.EndCap = LineCap.Round;
                            pen.StartCap = LineCap.Round;
                            panel.DrawLine(pen, Pm.pX[i], Pm.py[i], Pm.eX[i], Pm.eY[i]);
                            dialog.panel1.CreateGraphics().DrawImageUnscaled(dialog.drawing, new Point(0, 0));
                            // dialog.textBox1.Text += Pm.pX[i].ToString();
                        }
                    }
                    if (Pm.command == "Draw_Line")
                    {
                        // MessageBox.Show("Draw");
                        // dialog.textBox2.Text = "Draw";
                        Line[Line_index++] = Pm.Data - 1;
                        Graphics panel = Graphics.FromImage(dialog.drawing);
                        Pen pen = new Pen(System.Drawing.ColorTranslator.FromHtml(Pm.Color[Pm.Data - 1]), Pm.thick[Pm.Data - 1]);
                        pen.EndCap = LineCap.Round;
                        pen.StartCap = LineCap.Round;
                        panel.DrawLine(pen, Pm.pX[Pm.Data - 1], Pm.py[Pm.Data - 1], Pm.eX[Pm.Data - 1], Pm.eY[Pm.Data - 1]);
                        dialog.panel1.CreateGraphics().DrawImageUnscaled(dialog.drawing, new Point(0, 0));
                        all_index = Pm.Data - 1;

                    }
                    if (Pm.command == "Draw_Circle")
                    {
                        // MessageBox.Show("Draw");
                        // dialog.textBox2.Text = "Draw";
                        Circle[Cir_index++] = Pm.Data - 1;
                        Graphics panel = Graphics.FromImage(dialog.drawing);
                        Pen pen = new Pen(System.Drawing.ColorTranslator.FromHtml(Pm.Color[Pm.Data - 1]), Pm.thick[Pm.Data - 1]);
                        pen.EndCap = LineCap.Round;
                        pen.StartCap = LineCap.Round;
                        panel.DrawEllipse(pen, Pm.pX[Pm.Data - 1], Pm.py[Pm.Data - 1], Pm.eX[Pm.Data - 1], Pm.eY[Pm.Data - 1]);
                        dialog.panel1.CreateGraphics().DrawImageUnscaled(dialog.drawing, new Point(0, 0));
                        all_index = Pm.Data - 1;
                    }
                    if (Pm.command == "Draw_Rectangle")
                    {
                        // MessageBox.Show("Draw");
                        // dialog.textBox2.Text = "Draw";
                        Rec[Rec_index++] = Pm.Data - 1;
                        
                        Graphics panel = Graphics.FromImage(dialog.drawing);
                        Pen pen = new Pen(System.Drawing.ColorTranslator.FromHtml(Pm.Color[Pm.Data - 1]), Pm.thick[Pm.Data - 1]);
                        pen.EndCap = LineCap.Round;
                        pen.StartCap = LineCap.Round;
                        panel.DrawRectangle(pen, Pm.pX[Pm.Data - 1], Pm.py[Pm.Data - 1], Pm.eX[Pm.Data - 1], Pm.eY[Pm.Data - 1]);
                        dialog.panel1.CreateGraphics().DrawImageUnscaled(dialog.drawing, new Point(0, 0));
                        all_index = Pm.Data - 1;
                    }
                    Pm.Rec = Rec;
                    Pm.Line = Line;
                    Pm.Cir = Circle;
                    Pm.command = "AllDraw";
                    BackUp = Pm;
                }
                SendMessageAll(Pm, true, stream);
            }
        }
        void h_client_OnDisconnected(TcpClient clientSocket)
        {
            if (clientList.ContainsKey(clientSocket))
                clientList.Remove(clientSocket);
        }
        public void SendMessageAll(PMessage Master, bool flag, NetworkStream self)
        {
            foreach (var pair in clientList)
            {
                date = DateTime.Now.ToString("yyyy.MM.dd. HH:mm:ss"); // 현재 날짜 받기

                TcpClient client = pair.Key as TcpClient;
                NetworkStream stream = client.GetStream();
                if (stream == self)          
                    continue;
                if (flag)
                {
                    if (Master.command == "메시지")
                    {
                        Packet.Serialize(Master).CopyTo(this.sendBuffer, 0);
                        stream.Write(sendBuffer, 0, sendBuffer.Length);
                        stream.Flush();

                        Array.Clear(sendBuffer, 0, sendBuffer.Length);
                    }
                    if(Master.command== "AllDraw")
                    {
                        Packet.Serialize(Master).CopyTo(this.sendBuffer, 0);
                        stream.Write(sendBuffer, 0, sendBuffer.Length);
                        stream.Flush();
                    }
            
                }
            }
        }
        private void DisplayText(string text) // Server 화면에 출력
        {
            if (dialog.textBox1.InvokeRequired)
            {
                dialog.textBox1.BeginInvoke(new MethodInvoker(delegate
                {
                    dialog.textBox1.AppendText(text + Environment.NewLine);
                }));
            }
            else
                dialog.textBox1.AppendText(text + Environment.NewLine);
        }

private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void server2_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {         
                if (server_button.Text == "서버 열기")
                {
                 Thread ListenThread = new Thread(new ThreadStart(Listen));
                 ListenThread.IsBackground = true;
                ListenThread.Start();
                server_button.Text = "서버 닫기";
               
                }
                else
                {
                    Server.Stop();
                    server_button.Text = "서버 열기";
                    server_button.ForeColor = Color.Black;
                }
            }

        private void server2_FormClosed(object sender, FormClosedEventArgs e)
        {
            Bitmap Newimg = new Bitmap(dialog.drawing);

            dialog.drawing.Dispose();

            dialog.drawing = null;
            if (File.Exists("drawing"))
            {
                GC.Collect();
                GC.WaitForPendingFinalizers();
                FileInfo f = new FileInfo("drawing");
                f.Delete();
            }
            Newimg.Save("drawing", System.Drawing.Imaging.ImageFormat.Bmp);
          
        }
    }
}
