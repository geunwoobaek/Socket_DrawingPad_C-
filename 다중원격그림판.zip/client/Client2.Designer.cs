﻿namespace client
{
    partial class Client2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.IP_TEXT = new System.Windows.Forms.TextBox();
            this.PORT_TEXT = new System.Windows.Forms.TextBox();
            this.btn_Connect = new System.Windows.Forms.Button();
            this.UserName = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // IP_TEXT
            // 
            this.IP_TEXT.Location = new System.Drawing.Point(15, 22);
            this.IP_TEXT.Name = "IP_TEXT";
            this.IP_TEXT.Size = new System.Drawing.Size(245, 25);
            this.IP_TEXT.TabIndex = 0;
            // 
            // PORT_TEXT
            // 
            this.PORT_TEXT.Location = new System.Drawing.Point(267, 22);
            this.PORT_TEXT.Name = "PORT_TEXT";
            this.PORT_TEXT.Size = new System.Drawing.Size(97, 25);
            this.PORT_TEXT.TabIndex = 1;
            // 
            // btn_Connect
            // 
            this.btn_Connect.Location = new System.Drawing.Point(62, 98);
            this.btn_Connect.Name = "btn_Connect";
            this.btn_Connect.Size = new System.Drawing.Size(272, 49);
            this.btn_Connect.TabIndex = 2;
            this.btn_Connect.Text = "접속";
            this.btn_Connect.UseVisualStyleBackColor = true;
            this.btn_Connect.Click += new System.EventHandler(this.button1_Click);
            // 
            // UserName
            // 
            this.UserName.Location = new System.Drawing.Point(62, 67);
            this.UserName.Name = "UserName";
            this.UserName.Size = new System.Drawing.Size(273, 25);
            this.UserName.TabIndex = 3;
            this.UserName.TextChanged += new System.EventHandler(this.UserName_TextChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(21, 70);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(20, 15);
            this.label1.TabIndex = 4;
            this.label1.Text = "ID";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // Client2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(376, 159);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.UserName);
            this.Controls.Add(this.btn_Connect);
            this.Controls.Add(this.PORT_TEXT);
            this.Controls.Add(this.IP_TEXT);
            this.Name = "Client2";
            this.Text = "Form2";
            this.Load += new System.EventHandler(this.Form2_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox IP_TEXT;
        private System.Windows.Forms.TextBox PORT_TEXT;
        public System.Windows.Forms.Button btn_Connect;
        private System.Windows.Forms.Label label1;
        public System.Windows.Forms.TextBox UserName;
    }
}